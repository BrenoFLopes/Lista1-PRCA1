﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;
            double valor3;
            double valor4;
            double media;

            Console.Write("Digite o 1º dos 4 valores para cálculo de média aritmética: ");
            valor1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o 2º dos 4 valores para cálculo de média aritmética: ");
            valor2 = double.Parse(Console.ReadLine());

            Console.Write("Digite o 3º dos 4 valores para cálculo de média aritmética: ");
            valor3 = double.Parse(Console.ReadLine());

            Console.Write("Digite o 4º dos 4 valores para cálculo de média aritmética: ");
            valor4 = double.Parse(Console.ReadLine());

            media = (valor1 + valor2 + valor3 + valor4) / 4;        
            
            Console.WriteLine("A média aritmética dos valores {0}, {1}, {2} e {3} é igual a: {4}", valor1, valor2, valor3, valor4, media);
        }
    }
}
