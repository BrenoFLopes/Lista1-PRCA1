﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double celsius;
            double fahrenheit;

            Console.Write("Digite o número de graus Celsius a serem convertidos para graus Fahrenheit: ");
            celsius = double.Parse(Console.ReadLine());

            fahrenheit = ((celsius * 9)/5) + 32;

            Console.WriteLine("{0} grau(s) Celsius é equivalente a {1} grau(s) Fahrenheit.", celsius, fahrenheit);
        }
    }
}
