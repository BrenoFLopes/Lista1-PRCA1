﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;
            double media;

            Console.Write("Digite o 1º dos 2 valores para cálculo de média geométrica: ");
            valor1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o 2º dos 2 valores para cálculo de média geométrica: ");
            valor2 = double.Parse(Console.ReadLine());


            media = Math.Sqrt(valor1 * valor2);

            Console.WriteLine("A média geométrica dos valores {0} e {1} é igual a: {2}", valor1, valor2, media);
        }
    }
}
