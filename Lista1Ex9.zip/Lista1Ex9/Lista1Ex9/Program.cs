﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diametro;
            double area;

            Console.Write("Digite o valor do diâmetro do circulo: ");
            diametro = double.Parse(Console.ReadLine());

            area = Math.Pow((diametro / 2), 2) * Math.PI;
          
            Console.WriteLine("Com diâmetro igual a {0}, a área do circulo é igual a {1}.", diametro, area);
        }
    }
}
