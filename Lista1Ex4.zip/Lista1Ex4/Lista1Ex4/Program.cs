﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double base1;
            double altura1;
            double area;

            Console.Write("Digite o valor da base do triângulo: ");
            base1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor da altura do triângulo: ");
            altura1 = double.Parse(Console.ReadLine());

            area = (base1 * altura1) / 2;

            Console.WriteLine("A área do triângulo de base {0} e altura {1} é igual a: {2}", base1, altura1, area);
        }
    }
}
