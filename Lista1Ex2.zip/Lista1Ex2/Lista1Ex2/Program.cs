﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double aresta;
            double area;

            Console.Write("Digite o valor da aresta do quadrado: ");
            aresta = double.Parse(Console.ReadLine());

            area = Math.Pow(aresta, 2);
            Console.WriteLine("A área do quadrado de aresta {0} é igual a: {1}", aresta, area);
        }
    }
}
