﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diagonal;
            double aresta;
            double area;

            Console.Write("Digite o valor da diagonal do quadrado: ");
            diagonal = double.Parse(Console.ReadLine());

            aresta = diagonal / Math.Sqrt(2);
            
            area = Math.Pow(aresta, 2);
            Console.WriteLine("Com diagonal {0}, a área do quadrado é igual a: {1}", diagonal, area);
        }
    }
}
