﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double milhas;
            double km;

            Console.Write("Digite o número de milhas marítimas a serem convertidas para quilômetros: ");
            milhas = double.Parse(Console.ReadLine());

            km = milhas * 1.852 ;

            Console.WriteLine("{0} milha(s) marítima(s) é equivalente a {1} quilômetros.", milhas, km);
        }
    }
}
