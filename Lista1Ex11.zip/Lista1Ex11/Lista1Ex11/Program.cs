﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x;
            double y;
            double resultado;

            Console.Write("No cálculo de 'X^(Y)', digite o valor de 'X': ");
            x = int.Parse(Console.ReadLine());

            Console.Write("No cálculo de 'X^(Y)', digite o valor de 'Y': ");
            y = int.Parse(Console.ReadLine());

            resultado = Math.Pow(x, y);
            Console.WriteLine("O resultado do cálculo de '{0}^({1})' = {2}", x, y, resultado);

        }
    }
}
