﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double base1; 
            double altura1; 
            double area; 

            Console.Write("Digite o valor da base do retângulo: "); 
            base1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor da altura do retângulo: ");
            altura1 = double.Parse(Console.ReadLine());

            area = base1 * altura1;

            Console.WriteLine("A área do retângulo de base {0} e altura {1} é igual a: {2}", base1, altura1, area);
        }
    }
}
