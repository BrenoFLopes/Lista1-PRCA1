﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double produto1;
            double produto2;
            double produto3;
            double produto4;
            double produto5;
            double somaprodutos;
            double pagamento;
            double troco;

            Console.Write("Digite o valor do 1º item dos 5 itens: ");
            produto1 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 2º item dos 5 itens: ");
            produto2 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 3º item dos 5 itens: ");
            produto3 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 4º item dos 5 itens: ");
            produto4 = double.Parse(Console.ReadLine());

            Console.Write("Digite o valor do 5º item dos 5 itens: ");
            produto5 = double.Parse(Console.ReadLine());

            somaprodutos = produto1 + produto2 + produto3 + produto4 + produto5;

            Console.Write("O custo total dos itens foi de R$ {0}, informe o valor de pagamento: ", somaprodutos);
            pagamento = double.Parse(Console.ReadLine());

            troco = pagamento - somaprodutos;

            Console.WriteLine("O valor do troco é de R$ {0} ", troco);     
        }
    }
}
