﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double cot_dolar;
            double qtd_dolar;
            double real;

            Console.Write("Digite o valor da cotação desejada do Dólar (U$) para Real (R$): ");
            cot_dolar = double.Parse(Console.ReadLine());

            Console.Write("Digite da quantidade de dólares (U$) a ser convertido para real (R$): ");
            qtd_dolar = double.Parse(Console.ReadLine());

            real = cot_dolar * qtd_dolar;

            Console.WriteLine("U$ {0} com taxa cambial a R$ {1} é equivalente a R$ {2}.", qtd_dolar, cot_dolar, real);
        }
    }
}
